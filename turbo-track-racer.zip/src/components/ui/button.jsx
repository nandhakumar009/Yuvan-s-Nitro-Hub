import React from 'react'
export function Button({ children, className = '', variant, size, ...props }) {
  const base = 'inline-flex items-center justify-center rounded-lg px-3 py-2 border border-slate-700 bg-slate-800 hover:bg-slate-700 text-white text-sm';
  return <button className={base + ' ' + className} {...props}>{children}</button>
}
