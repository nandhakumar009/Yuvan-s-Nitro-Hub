import React from 'react'
export function Card({ children, className = '' }) {
  return <div className={'rounded-2xl border border-slate-700 bg-slate-800/60 ' + className}>{children}</div>
}
export function CardHeader({ children, className='' }) {
  return <div className={'p-4 border-b border-slate-700 ' + className}>{children}</div>
}
export function CardContent({ children, className='' }) {
  return <div className={'p-4 ' + className}>{children}</div>
}
export function CardTitle({ children, className='' }) {
  return <div className={'text-lg font-semibold flex items-center gap-2 ' + className}>{children}</div>
}
