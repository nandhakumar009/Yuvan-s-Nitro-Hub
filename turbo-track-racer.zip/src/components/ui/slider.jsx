import React from 'react'
export function Slider({ value=[0], onValueChange, min=0, max=100, step=1, className='' }) {
  const v = value[0]
  const handle = (e)=> onValueChange && onValueChange([Number(e.target.value)])
  return (
    <input type="range" min={min} max={max} step={step} value={v} onChange={handle}
      className={'w-full ' + className} />
  )
}
