import React from 'react'
export function Select({ value, onValueChange, children }) {
  return <div>{React.Children.map(children, c=>React.cloneElement(c, { value, onValueChange }))}</div>
}
export function SelectTrigger({ children, className='' }) { return <div className={'mt-1 ' + className}>{children}</div> }
export function SelectValue({ placeholder }) { return <span>{placeholder}</span> }
export function SelectContent({ children }) { return <div className='border border-slate-700 rounded-lg overflow-hidden'>{children}</div> }
export function SelectItem({ value, children, onValueChange }) {
  const handle = () => onValueChange && onValueChange(value);
  return <div onClick={handle} className='px-3 py-2 bg-slate-900 hover:bg-slate-800 cursor-pointer text-white'>{children}</div>
}
